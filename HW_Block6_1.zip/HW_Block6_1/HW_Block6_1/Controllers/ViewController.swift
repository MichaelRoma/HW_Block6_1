//
//  ViewController.swift
//  HW_Block6_1
//
//  Created by Mykhailo Romanovskyi on 14.07.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    
    let a = UITextView()
    private var pathComponent = ""
    private var list: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Хотите узнать путь к созданым файлм и папкам - раскомментируйте код
        //  print(FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!)
        list = StorageManager.shared.listFiles(at: pathComponent)
    }
    
    @IBAction func addFile(_ sender: UIBarButtonItem) {
        creatingFileOrDirectoryAlert(with: "File name")
    }
    
    @IBAction func addDirectory(_ sender: UIBarButtonItem) {
        creatingFileOrDirectoryAlert(with: "Directory name")
    }
}

//MARK: UITableViewDataSource
extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "List", for: indexPath)
        let name = list[indexPath.row]
        cell.textLabel?.text = name
        return cell
    }
}

//MARK: UITableViewDataDelegat
extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            StorageManager.shared.deleteDirOrFile(with: list[indexPath.row], at: pathComponent)
            list.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        var newPathComponent: String
        guard var url = StorageManager.shared.documentDirectory else { return }
        
        if pathComponent.isEmpty {
            url = url.appendingPathComponent(list[indexPath.row])
            newPathComponent = list[indexPath.row]
            
        } else {
            url = url.appendingPathComponent(pathComponent + "/" + list[indexPath.row])
            newPathComponent = pathComponent + "/" + list[indexPath.row]
        }
        
        if let text = StorageManager.shared.checkForContent(atPath: url.path) {
            goToTextView(with: text, newTitle: list[indexPath.row])
            
        } else {
            goToNextView(newPathComponent: newPathComponent, newTitle: list[indexPath.row])
        }
    }
    
    private func goToNextView(newPathComponent: String, newTitle: String) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let newVC = storyboard.instantiateViewController(identifier: "MainVC") as ViewController
        newVC.pathComponent = newPathComponent
        newVC.title = newTitle
        navigationController?.pushViewController(newVC, animated: true)
    }
    
    private func goToTextView(with data: Data, newTitle: String) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let newVC = storyboard.instantiateViewController(identifier: "TextView") as TextView
        newVC.title = newTitle
        newVC.text = String(bytes: data, encoding: .utf8) ?? ""
        navigationController?.pushViewController(newVC, animated: true)
    }
}

//MARK: Alerts
extension ViewController {
    
    private func creatingFileOrDirectoryAlert(with name: String) {
        let alert = UIAlertController(title: name, message: nil, preferredStyle: .alert)
        alert.addTextField(configurationHandler: nil)
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let create = UIAlertAction(title: "Create", style: .default) { (_) in
            if name == "Directory name" {
                if let text = alert.textFields?.first?.text, text != "" {
                    StorageManager.shared.createDirectory(with: text, at: self.pathComponent)
                    self.list = StorageManager.shared.listFiles(at: self.pathComponent)
                    self.tableView.reloadData()
                }
            } else {
                if let text = alert.textFields?.first?.text, text != "" {
                    StorageManager.shared.createFile(with: text , at: self.pathComponent)
                    self.list = StorageManager.shared.listFiles(at: self.pathComponent)
                    self.tableView.reloadData()
                }
            }
        }
        alert.addAction(cancel)
        alert.addAction(create)
        self.present(alert, animated: true)
    }
}
