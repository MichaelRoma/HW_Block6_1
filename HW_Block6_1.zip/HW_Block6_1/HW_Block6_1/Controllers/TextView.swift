//
//  TextView.swift
//  HW_Block6_1
//
//  Created by Mykhailo Romanovskyi on 16.07.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class TextView: UIViewController {
    @IBOutlet weak var textView: UITextView!
    var text = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        textView.text = text
    }
}
