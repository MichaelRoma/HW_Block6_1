//
//  FileManager.swift
//  HW_Block6_1
//
//  Created by Mykhailo Romanovskyi on 14.07.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import Foundation

class StorageManager {
    
    static let shared = StorageManager()
    
    let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    
    private init() {}
    
    func listFiles(at path: String) -> [String] {
        guard let url = documentDirectory?.appendingPathComponent(path), let list = try?
            FileManager.default.contentsOfDirectory(atPath: url.path) else { return [] }
        let dirArray = list.filter({ checkForContent(atPath: url.path + $0) == nil }).sorted()
        let fileArray = list.filter({ checkForContent(atPath: url.path + $0) != nil }).sorted()

        return dirArray + fileArray
    }
    func createDirectory(with name: String, at path: String) {
        guard let url = documentDirectory?.appendingPathComponent(path).appendingPathComponent(name) else { return }
        
        if FileManager.default.fileExists(atPath: url.path) {
            print("You alreade Have file with this name")
        } else {
            try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: false, attributes: nil)
        }
    }
    
    func createFile(with name: String, at path: String) {
        guard let url = documentDirectory?.appendingPathComponent(path).appendingPathComponent(name) else { return }
        if FileManager.default.fileExists(atPath: url.path) {
            print("You alreade Have file with this name")
        } else {
            let content = "Hello World".data(using: .utf8)
            FileManager.default.createFile(atPath: url.path, contents: content, attributes: nil)
        }
    }
    func deleteDirOrFile(with name: String, at path: String) {
        guard let url = documentDirectory?.appendingPathComponent(path).appendingPathComponent(name) else { return }
        try? FileManager.default.removeItem(at: url)
    }
    
    func checkForContent(atPath: String) -> Data? {
        FileManager.default.contents(atPath: atPath)
    }
}
